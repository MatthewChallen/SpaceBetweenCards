package TypeListings;


public enum ObjectType {
    PLAYERSHIP,
    ENEMYSHIP,
    DEBRIS,
    WARP,
    PROJECTILE
}
